from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from .models import UserProfile
from django_countries.fields import CountryField
from django_countries.widgets import CountrySelectWidget

class RegisterForm(UserCreationForm):
	phone = forms.CharField(max_length=13)
	email = forms.EmailField()
	first_name = forms.CharField(max_length=50)
	last_name = forms.CharField(max_length=50)
	street_address = forms.CharField(max_length=100)
	apartment_address = forms.CharField(max_length=100)
	country = CountryField(blank_label='(select country)').formfield(
		widget=CountrySelectWidget(attrs={
			'class': 'custom-select d-block w-100',
		}))
	zipcode = forms.CharField(max_length=100)

	class Meta:
		model = UserProfile
		fields = ["username", "email", "password1", "password2", 'first_name', 'last_name', 'phone',
				'zipcode', 'street_address', 'apartment_address', 'country']

	def save(self, commit=True):
		user = super(RegisterForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		user.phone = self.cleaned_data['phone']
		user.first_name = self.cleaned_data['first_name']
		user.last_name = self.cleaned_data['last_name']
		user.zipcode = self.cleaned_data['zipcode']
		user.street_address = self.cleaned_data['street_address']
		user.apartment_address = self.cleaned_data['apartment_address']
		user.country = self.cleaned_data['country']
		if commit:
			user.save()
		return user

class EditForm(UserChangeForm):
	# password = None

	class Meta:
		model = UserProfile
		fields = ['email', 'first_name', 'last_name','phone', 'zipcode', 'street_address', 'apartment_address', 'country']
