from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from .views import (
	HomeView,
	OrderSummaryView,
	ItemDetailView,
	add_to_cart,
	remove_from_cart,
	remove_single_item_from_cart,
	category,
	register_request,
	login_request,
	logout_request,
	payment,
	UserView,
	CheckoutView,
	# user_edit_request,
	UserEditView,
	change_password,
	)

app_name = 'main'

urlpatterns = [
	path('', HomeView.as_view(), name='Main page'),
	path('category/<slug>/', category, name = 'category'),
	path("register/", register_request, name="register"),
	path("login/", login_request, name="login"),
	path("logout", logout_request, name= "logout"),
	path('order-summary/', OrderSummaryView.as_view(), name='order-summary'),
	path('product/<slug>/', ItemDetailView.as_view(), name='product'),
	path('add-to-cart/<slug>/', add_to_cart, name='add-to-cart'),
	path('remove-from-cart/<slug>/', remove_from_cart, name='remove-from-cart'),
	path('remove-item-from-cart/<slug>/', remove_single_item_from_cart,
		 name='remove-single-item-from-cart'),
	path('payment', payment, name = 'payment'),
	path('checkout', CheckoutView.as_view(), name = 'checkout'),
	path('info/', UserView.as_view(), name='info'),
	# path('edit_profile/', user_edit_request, name='edit_profile'),
	path('edit_profile/', UserEditView.as_view(), name='edit_profile'),
	path('change_password/', change_password, name='change_password'),

]
if settings.DEBUG:
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)