from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import DetailView, ListView, View, UpdateView
from django.utils import timezone
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.forms import AuthenticationForm, UserChangeForm, PasswordChangeForm

from .models import Category, Product, UserProfile, Order, OrderItem, OrderHistory
from .forms import RegisterForm, EditForm#, UserEdit

def register_request(request):
	if request.method == "POST":
		form = RegisterForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Успешная регистрация!" )
			return redirect("main:Main page")
		messages.error(request, "Регистрация не завершена, проверьте введенную инфомацию.")
	form = RegisterForm()
	return render (request=request, template_name="register.html", context={"register_form":form})

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"Вы вошли как {username}.")
				return redirect("main:Main page")
			else:
				messages.error(request,"Неверное имя пользователя или пароль.")
		else:
			messages.error(request,"Неверное имя пользователя или пароль.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})

@login_required
def logout_request(request):
	logout(request)
	messages.info(request, "Вы успешно вышли") 
	return redirect("main:Main page")

def change_password(request):
	if request.method == 'POST':
		form = PasswordChangeForm(request.user, request.POST)
		if form.is_valid():
			user = form.save()
			update_session_auth_hash(request, user) 
			messages.success(request, 'Пароль успешно изменен!')
			return redirect('main:info')
		else:
			messages.error(request, 'Ошибка!')
	else:
		form = PasswordChangeForm(request.user)
	return render(request, 'change_password.html', {
		'form': form
	})

# def user_edit_request(request):
# 	if request.POST:
# 		profileform = EditForm(request.POST, instance=request.user.userprofile)
# 		if profileform.is_valid():
# 			profileform.save()
# 			messages.success(request, "Данные изменены" )
# 			return redirect("main:info")
# 		else: 
# 			messages.error(request, "Данные не изменены, проверьте введенную инфомацию.")
# 	else:
# 		profileform = EditForm(request.POST, instance=request.user.userprofile)
# 	return render(request=request, template_name="edit_profile.html", context={'profileform':profileform})

class UserEditView(UpdateView):
	form_class = EditForm
	template_name="edit_profile.html" 
	success_url = reverse_lazy('main:info')
	def get_object(self):
		return self.request.user.userprofile


class HomeView(ListView):
	model = Product
	paginate_by = 10
	template_name = "main.html"
	
	def get_context_data(self, **kwargs):
		context = super(HomeView, self).get_context_data(**kwargs)
		context['Category'] = Category.objects.all()
		return context

def product_detail(request, slug):
	product = get_object_or_404(Product,
								slug=slug,
								available=True)
	return render(request,
				  'product.html',
				  {'product': product})

class UserView(ListView):
	model = UserProfile
	template_name = "info.html"

	def get_context_data(self, **kwargs):
		context = super(UserView, self).get_context_data(**kwargs)
		temp = OrderHistory.objects.filter(user = self.request.user)
		temp2 = []
		for i in temp:
			temp2.append(i)
		context['OrderHistory'] = temp2
		return context

class OrderSummaryView(LoginRequiredMixin, View):
	def get(self, *args, **kwargs):
		try:
			order = Order.objects.get(user=self.request.user, ordered=False)
			context = {
				'object': order
			}
			return render(self.request, 'order_summary.html', context)
		except ObjectDoesNotExist:
			messages.warning(self.request, "Ваша корзина пуста")
			return redirect("/")


class ItemDetailView(DetailView):
	model = Product
	template_name = "product.html"

def category(request, slug=None):
	data = Product.objects.filter(available=True)
	categories = Category.objects.all()
	category = Category.objects.get(slug=slug)
	if slug:
		cat_name = get_object_or_404(Category, slug=slug)
		data = data.filter(category=category)
	return render(request,
				  'category.html',
				  {'category': category,
				   'categories': categories,
				   'data': data})


@login_required
def add_to_cart(request, slug):
	item = get_object_or_404(Product, slug=slug)
	order_item, created = OrderItem.objects.get_or_create(
		product=item,
		user=request.user,
		ordered=False
	)
	order_qs = Order.objects.filter(user=request.user, ordered=False)
	if order_qs.exists():
		order = order_qs[0]
		if order.items.filter(product__slug=item.slug).exists():
			order_item.quantity += 1
			order_item.save()
			messages.info(request, "Количество обновлено")
			return redirect("main:order-summary")
		else:
			order.items.add(order_item)
			messages.info(request, "Товар добавлен в корзину")
			return redirect("Товар добавлен в корзину")
	else:
		ordered_date = timezone.now()
		order = Order.objects.create(
			user=request.user, ordered_date=ordered_date)
		order.items.add(order_item)
		messages.info(request, "Товар добавлен в корзину")
		return redirect("main:order-summary")


@login_required
def remove_from_cart(request, slug):
	item = get_object_or_404(Product, slug=slug)
	order_qs = Order.objects.filter(
		user=request.user,
		ordered=False
	)
	if order_qs.exists():
		order = order_qs[0]
		if order.items.filter(product__slug=item.slug).exists():
			order_item = OrderItem.objects.filter(
				product=item,
				user=request.user,
				ordered=False
			)[0]
			order.items.remove(order_item)
			order_item.delete()
			messages.info(request, "Товар удален из корзины")
			return redirect("main:order-summary")
		else:
			messages.info(request, "Товара нет в корзине!")
			return redirect("main:product", slug=slug)
	else:
		messages.info(request, "Ваша корзина пуста")
		return redirect("main:product", slug=slug)


@login_required
def remove_single_item_from_cart(request, slug):
	item = get_object_or_404(Product, slug=slug)
	order_qs = Order.objects.filter(
		user=request.user,
		ordered=False
	)
	if order_qs.exists():
		order = order_qs[0]
		if order.items.filter(product__slug=item.slug).exists():
			order_item = OrderItem.objects.filter(
				product=item,
				user=request.user,
				ordered=False
			)[0]
			if order_item.quantity > 1:
				order_item.quantity -= 1
				order_item.save()
			else:
				order.items.remove(order_item)
			messages.info(request, "Количество обновлено")
			return redirect("main:order-summary")
		else:
			messages.info(request, "Товара нет в корзине!")
			return redirect("main:product", slug=slug)
	else:
		messages.info(request, "Ваша корзина пуста")
		return redirect("main:product", slug=slug)


class CheckoutView(ListView):

	def get(self, *args, **kwargs):
		order = Order.objects.get(user=self.request.user, ordered=False)
		context = {'Order': order}
		return render(self.request, "checkout.html", context)

@login_required
def payment(request):
	order = Order.objects.filter(user=request.user, ordered=False)
	temp = []
	price = 0
	for i in order:
		for j in i.items.all():
			temp.append(str(j))
		price += i.get_total()
	oh = OrderHistory(user=request.user, price=price, items=str(temp), date=timezone.now())
	oh.save()
	order.delete()
	OrderItem.objects.filter(user=request.user, ordered=False).delete()
	messages.info(request, "Заказ оформлен!")
	return redirect("main:info")
