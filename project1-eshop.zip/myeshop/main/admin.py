from django.contrib import admin
from .models import Category, Product, UserProfile, Order, OrderItem, OrderHistory


class CategoryAdmin(admin.ModelAdmin):
	list_display = ['name', 'slug']
	prepopulated_fields = {'slug': ('name',)}

admin.site.register(Category, CategoryAdmin)

class ProductAdmin(admin.ModelAdmin):
	list_display = ['name', 'slug', 'price', 'available']
	list_editable = ['price', 'available']
	prepopulated_fields = {'slug': ('name',)}

admin.site.register(Product, ProductAdmin)

admin.site.register(UserProfile)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(OrderHistory)