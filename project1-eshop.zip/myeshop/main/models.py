from django.db import models
from django.conf import settings
from django_countries.fields import CountryField
from django.contrib.auth.models import User
from django.shortcuts import reverse

class UserProfile(User):
	phone = models.CharField(max_length=13, blank=True, null=True)
	street_address = models.CharField(max_length=100)
	apartment_address = models.CharField(max_length=100)
	country = CountryField(multiple=False)
	zipcode = models.CharField(max_length=100)

	def __str__(self):
		return self.username

	class Meta:
		verbose_name = 'Пользователь'
		verbose_name_plural = 'Пользователи'

class Category(models.Model):
	name = models.CharField(max_length=200, db_index=True)
	slug = models.SlugField(max_length=200, db_index=True, unique=True)

	class Meta:
		ordering = ('name',)
		verbose_name = 'Категория'
		verbose_name_plural = 'Категории'

	def __str__(self):
		return self.name

	def get_absolute_url(self):
		return reverse('main:category',
						kwargs={'slug': self.slug})


class Product(models.Model):
	category = models.ForeignKey(Category, related_name='products', on_delete = models.CASCADE)
	name = models.CharField(max_length=200, db_index=True)
	slug = models.SlugField(max_length=200, db_index=True)
	image = models.ImageField(upload_to='products/%Y/%m/%d', blank=True)
	description = models.TextField(blank=True)
	price = models.DecimalField(max_digits=10, decimal_places=2)
	# stock = models.PositiveIntegerField()
	available = models.BooleanField(default=True)

	class Meta:
		ordering = ('name',)
		index_together = (('id', 'slug'),)
		verbose_name = 'Товар'
		verbose_name_plural = 'Товары'

	def __str__(self):
		return self.name

	def get_absolute_url(self):
		return reverse('main:product',
						kwargs={'slug': self.slug})

	def get_add_to_cart_url(self):
		return reverse("main:add-to-cart", kwargs={
			'slug': self.slug
		})

	def get_remove_from_cart_url(self):
		return reverse("main:remove-from-cart", kwargs={
			'slug': self.slug
		})

class OrderItem(models.Model):
	user = models.ForeignKey(settings.AUTH_USER_MODEL,
							on_delete=models.CASCADE)
	product = models.ForeignKey(Product, on_delete=models.CASCADE)
	quantity = models.IntegerField(default=1)
	ordered = models.BooleanField(default=False)

	def __str__(self):
		return f"{self.quantity} of {self.product.name}"

	def get_total_item_price(self):
		return self.quantity * self.product.price

class Order(models.Model):
	user = models.ForeignKey(settings.AUTH_USER_MODEL,
							on_delete=models.CASCADE)
	items = models.ManyToManyField(OrderItem)
	start_date = models.DateTimeField(auto_now_add=True)
	ordered_date = models.DateTimeField()
	ordered = models.BooleanField(default=False)
	paid = models.BooleanField(default=False)

	def __str__(self):
		return self.user.username

	def get_total(self):
		total = 0
		for order_item in self.items.all():
			total += order_item.get_total_item_price()
		return total

	class Meta:
		verbose_name = 'Заказ'
		verbose_name_plural = 'Заказы'

class OrderHistory(models.Model):
	user = models.ForeignKey(settings.AUTH_USER_MODEL,
							on_delete=models.CASCADE)
	items = models.TextField()
	price = models.DecimalField(max_digits=10, decimal_places=2)
	date = models.DateTimeField(auto_now_add=True)
	
	def __str__(self):
		return f"Заказ № {self.id} пользователя {self.user.username}"

	class Meta:
		verbose_name = 'История'
		verbose_name_plural = 'История заказов'