from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import DetailView, ListView, View, UpdateView, CreateView, DeleteView
from django.utils import timezone
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.forms import AuthenticationForm, UserChangeForm, PasswordChangeForm
from django.db.models import Q
from .models import UserProfile, Post, Tag, Comment
from .forms import RegisterForm, PostForm, EditForm, CommentForm


def register_request(request):
	if request.method == "POST":
		form = RegisterForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Успешная регистрация!" )
			return redirect("blog:Main page")
		messages.error(request, "Регистрация не завершена, проверьте введенную инфомацию.")
	form = RegisterForm()
	return render (request=request, template_name="register.html", context={"register_form":form})

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"Вы вошли как {username}.")
				return redirect("blog:Main page")
			else:
				messages.error(request,"Неверное имя пользователя или пароль.")
		else:
			messages.error(request,"Неверное имя пользователя или пароль.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})

@login_required
def logout_request(request):
	logout(request)
	messages.info(request, "Вы успешно вышли") 
	return redirect("blog:Main page")

def change_password(request):
	if request.method == 'POST':
		form = PasswordChangeForm(request.user, request.POST)
		if form.is_valid():
			user = form.save()
			update_session_auth_hash(request, user) 
			messages.success(request, 'Пароль успешно изменен!')
			return redirect('blog:info')
		else:
			messages.error(request, 'Ошибка!')
	else:
		form = PasswordChangeForm(request.user)
	return render(request, 'change_password.html', {
		'form': form
	})


class HomeView(ListView):
	model = Post
	# paginate_by = 10
	template_name = "mainpage.html"
	ordering = ['-timestamp']

	def get_context_data(self, **kwargs):
		context = super(HomeView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		return context

class PostDetailView(DetailView):
	model = Post
	template_name = "post.html"

	def get_context_data(self, **kwargs):
		context = super(PostDetailView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		return context

class ProfilePageView(DetailView):
	model = UserProfile
	template_name = "profile_page.html"

	def get_context_data(self, **kwargs):
		context = super(ProfilePageView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		context['post'] = Post.objects.filter(author=self.kwargs['pk'])
		return context

class AddPostView(CreateView):
	model = Post
	form_class = PostForm
	template_name = "add_post.html"
	
	def get_context_data(self, **kwargs):
		context = super(AddPostView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		return context

	# def get_initial(self):
	# 	initial = super(AddPostView, self).get_initial()
	# 	user = UserProfile.objects.get(username=self.request.user.username)
	# 	initial.update({'author_id': user.id})
	# 	return initial

	def form_valid(self, form):
		user = UserProfile.objects.get(username=self.request.user.username)
		form.instance.author_id = user.id 
		return super().form_valid(form)

class AddCommentView(CreateView):
	model = Comment
	form_class = CommentForm
	template_name = "add_comment.html"

	def get_success_url(self):
		post_id = self.object.post.id
		return reverse_lazy('blog:post', kwargs={'pk':post_id})

	def form_valid(self, form):
		user = UserProfile.objects.get(username=self.request.user.username)
		form.instance.author_id = user.id
		form.instance.post_id = self.kwargs['pk'] 
		return super().form_valid(form)


class EditPostView(UpdateView):
	model = Post
	form_class = EditForm
	template_name = "edit_post.html"

	def get_context_data(self, **kwargs):
		context = super(EditPostView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		return context

class DeletePostView(DeleteView):
	model = Post
	template_name = "delete_post.html"
	success_url = reverse_lazy('blog:Main page')

	def get_context_data(self, **kwargs):
		context = super(DeletePostView, self).get_context_data(**kwargs)
		context['tag'] = Tag.objects.all()
		return context

def TagView(request, tags):
	taggs=Tag.objects.get(name=tags)
	posts = Post.objects.filter(tags=taggs)
	tag = Tag.objects.all()
	return render(request, 'tag.html', {'tags':tags, 'posts':posts, 'tag':tag})

class TagsView(ListView):
	model = Tag
	template_name = "tags.html"

	def get_context_data(self, **kwargs):
		context = super(TagsView, self).get_context_data(**kwargs)
		context['posts'] = Post.objects.all()
		return context

def search_result(request):
	if request.method == "POST":
		query = request.POST.get('searchbox')
		# posts = Post.objects.filter(Q(title__contains=query) | Q(author__contains=query) | Q(content__contains=query))
		posts = Post.objects.filter(title__contains=query) | Post.objects.filter(content__contains=query) 
		return render(request=request, template_name="search_result.html", context={'searched':query,'posts':posts})
	else:
		return render(request=request, template_name="search_result.html", context={})

def delete_comment(request, pk):
	Comment.objects.filter(id=pk).delete()
	# post = Post.objects.filter(id=request.GET['pk'])
	# return render(request, 'post.html', {'post':post})
	return redirect(request.META.get('HTTP_REFERER'))
