from django.db import models
from django.conf import settings
from django_countries.fields import CountryField
from django.contrib.auth.models import User
from django.shortcuts import reverse
from ckeditor.fields import RichTextField

class UserProfile(User):
	phone = models.CharField(max_length=13, blank=True, null=True)
	country = CountryField(multiple=False)
	avatar = models.ImageField(blank=True, null=True, default='blank_avatar.jpg')
	bio = models.CharField(max_length=200, default='Обо мне...', blank=True, null=True)

	def __str__(self):
		return self.username

	class Meta:
		verbose_name = 'Пользователь'
		verbose_name_plural = 'Пользователи'

	def post_count(self):
		posts = Post.objects.filter(author=self)
		count = 0
		for item in posts:
			count += 1
		return count

class Tag(models.Model):
	name = models.CharField(max_length=200)

	def __str__(self):
		return self.name

	def get_absolute_url(self):
		return reverse('blog:Main page')

	def post_count_by_tag(self):
		result = {}
		posts = Post.objects.all()
		count = 0
		for item in posts:
			if item.tags.filter(name=self.name):
				count += 1
		return count

class Post(models.Model):
	title = models.CharField(max_length=200)
	author = models.ForeignKey(
		'UserProfile',
		on_delete=models.CASCADE,
	)
	# content = models.TextField()
	content = RichTextField(blank=True, null=True)
	image = models.ImageField(blank=True, null=True, upload_to="media/")
	updated = models.DateTimeField(auto_now=True, auto_now_add=False)
	timestamp = models.DateTimeField(auto_now=False, auto_now_add=True) 
	tags = models.ManyToManyField(Tag)
	snippet = models.CharField(max_length=120, default='Краткое описание поста....')

	def __str__(self):
		return self.title

	def get_absolute_url(self):
		return reverse('blog:Main page')

class Comment(models.Model):
	post = models.ForeignKey(Post, related_name="comments", on_delete=models.CASCADE)
	author = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
	content = RichTextField(blank=True, null=True)
	timestamp = models.DateTimeField(auto_now=False, auto_now_add=True) 