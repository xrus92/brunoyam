from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from .views	import (
	HomeView,
	register_request,
	login_request,
	logout_request,
	change_password,
	PostDetailView,
	ProfilePageView,
	AddPostView,
	# add_post,
	EditPostView,
	DeletePostView,
	TagView,
	AddCommentView,
	TagsView,
	search_result,
	delete_comment,
	)
app_name = 'blog'

urlpatterns = [
	path('', HomeView.as_view(), name='Main page'),
	path('post/<int:pk>/', PostDetailView.as_view(), name='post'),
	path("register/", register_request, name="register"),
	path("login/", login_request, name="login"),
	path("logout", logout_request, name= "logout"),
	path('change_password/', change_password, name='change_password'),
	path('profile_page/<int:pk>/', ProfilePageView.as_view(), name='profile_page'),
	path('add_post/', AddPostView.as_view(), name='add_post'),
	path('post/edit/<int:pk>/', EditPostView.as_view(), name='edit_post'),
	path('post/<int:pk>/delete', DeletePostView.as_view(), name='delete_post'),
	path('tag/<str:tags>/', TagView, name='TagView'),
	path('post/<int:pk>/comment', AddCommentView.as_view(), name='add_comment'),
	path("tags/", TagsView.as_view(), name="tags"),
	path("search_result/", search_result, name="search-result"),
	path("<int:pk>/delete_comment", delete_comment, name="delete_comment"),
]
if settings.DEBUG:
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)