from django.contrib import admin
from .models import UserProfile, Post, Tag, Comment

class PostModelAdmin(admin.ModelAdmin):
	list_display = ["id" ,"title", "updated", "timestamp"]
	list_display_links = ["id", "updated"]
	list_editable = ["title"]
	list_filter = ["updated", "timestamp"]
	search_fields = ["title", "content"]
	class Meta:
		model = Post


admin.site.register(UserProfile)
admin.site.register(Tag)
admin.site.register(Post, PostModelAdmin)
admin.site.register(Comment)