from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile, Post, Tag, Comment
from django_countries.fields import CountryField
from django_countries.widgets import CountrySelectWidget

choices = Tag.objects.all().values_list('name', 'name')

class RegisterForm(UserCreationForm):
	phone = forms.CharField(max_length=13)
	email = forms.EmailField()
	first_name = forms.CharField(max_length=50)
	last_name = forms.CharField(max_length=50)
	country = CountryField(blank_label='(select country)').formfield(
		widget=CountrySelectWidget(attrs={
			'class': 'custom-select d-block w-100',
		}))

	class Meta:
		model = UserProfile
		fields = ["username", "email", "password1", "password2", 'first_name', 'last_name', 'phone', 'country']

	def save(self, commit=True):
		user = super(RegisterForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		user.phone = self.cleaned_data['phone']
		user.first_name = self.cleaned_data['first_name']
		user.last_name = self.cleaned_data['last_name']
		user.country = self.cleaned_data['country']
		if commit:
			user.save()
		return user

class PostForm(forms.ModelForm):

	class Meta:
		model = Post
		fields = ('title', 'tags', 'image', 'content', 'snippet' )
		labels = {
		'title': 'Название',
		'tags': 'Теги',
		'image': 'Изображение',
		'content': 'Текст',
		'snippet': 'Кратко',
		 }
		widgets = {
		'title': forms.TextInput(attrs={'class':'form-control','placeholder':"Название поста"}),
		'tags': forms.CheckboxSelectMultiple(choices=choices, attrs={'class':'form-control'}),
		'content': forms.Textarea(attrs={'class':'form-control', 'placeholder':"Текст поста"}),
		'snippet': forms.TextInput(attrs={'class':'form-control', 'placeholder':"Краткое описание поста..."}),
		}

class EditForm(forms.ModelForm):

	class Meta:
		model = Post
		fields = ('title', 'image', 'content', 'tags','snippet')

		labels = {'title': 'Название',
		'tags': 'Теги',
		'image': 'Изображение',
		'content': 'Текст',
		'snippet': 'Кратко',
		 }

		widgets = {
		'tags': forms.CheckboxSelectMultiple(choices=choices, attrs={'class':'form-control'}),
		}

class CommentForm(forms.ModelForm):
		
	class Meta:
		model = Comment
		fields = ('content',)

		labels = {'content': 'Ваш комментарий'}

		widgets = {
		'content': forms.Textarea(attrs={'class':'form-control', 'placeholder':"Текст поста"}),
		}